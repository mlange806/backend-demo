from setuptools import setup, find_packages

setup(name="backend-demo", packages=find_packages())
